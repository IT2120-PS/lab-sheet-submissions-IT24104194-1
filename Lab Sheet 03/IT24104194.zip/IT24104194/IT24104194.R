
student_data <- read.csv("Exercise.csv", header = TRUE, stringsAsFactors = FALSE)
str(student_data)
head(student_data)

summary(student_data$X1)

hist(student_data$X1,
     main = "Histogram of Age (X1)",
     xlab = "Age",
     ylab = "Frequency")

gender_tab <- table(student_data$X2)
gender_tab
prop.table(gender_tab)
barplot(gender_tab,
        main = "Gender Distribution (X2)",
        xlab = "Gender",
        ylab = "Count",
        col=c("pink","purple"))


boxplot(X1 ~ X3, data = student_data,
        main = "Age by Accommodation Type",
        xlab = "Accommodation (X3)",
        ylab = "Age",
        col=c("lightblue","lightgreen","red")
        )

tapply(student_data$X1, student_data$X3, summary)


aggregate(X1 ~ X3, data = student_data, FUN = mean)


aggregate(X1 ~ X3, data = student_data, FUN = median)

